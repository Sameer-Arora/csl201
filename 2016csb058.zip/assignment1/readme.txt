
To compile & run the system just open the assignment1 directory and run make command in terminal.  
Then run the executable as ./ass1.

There are five cpp files("r.cpp","llist.cpp","car.cpp","truck.cpp","bus.cpp") and three header files ("car.h","truck.h","bus.h").
The r.cpp is the main file.

The use of various functionalities are mentioned in the comments.

Function​ ​ overloading-It is used in the constructors.

Operator​ ​ overloading-It is used to print details ,compare two classes.

Constructors​ ​ and​ ​ destructors-They are used to set the  members of different classes.Destructors are defined only for linked list.

Inheritance-Car is based class and bus ,truck are derived from it.

Virtual​ ​ functions-They are used for booking and unbooking functions.

Dynamic​ ​ memory​ ​ allocation-It is used while adding new nodes.

Function​ ​ templates-In this system i have  used a common linked list class for all vehicles using the templates.

Access​ ​ specifiers-Every data member of the class is private or protected.
